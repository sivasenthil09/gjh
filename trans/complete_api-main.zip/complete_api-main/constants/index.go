// define all the constants that we will use in the application.

package constants

const ConnectionString ="mongodb://localhost:27017"
const Port =":4000"
const DatabaseName ="netxdb"
//"mongodb+srv://userone:L2ORM855sl5XzunU@cluster0.9eqsnyg.mongodb.net/"
